import { helper } from '@ember/component/helper';
//import Ember from 'ember';

export function arrayContains(params) {
  const [items, value] = params; //chacune des variable est affecte à une value
  return items.includes(value);
}

//export default Ember.Helper.helper(arrayContains);
export default helper(arrayContains);