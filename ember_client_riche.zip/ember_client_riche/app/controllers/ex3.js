import Controller from '@ember/controller';
import {get} from '@ember/object';

export default Controller.extend({
  copyArrayElements(fromName,toName){
    //to.push.apply(to,from);
    let model = this.get('model');
    let from = get(model, fromName); // _ car computed --> ce qui change
    let to = get(model, toName);
    to.pushObjects(from); // permets de modifier l'interface em meme temps que la vue est modifée
  },
  removeElement(){

  },
  actions:{
    addToIncluded(){
      //let model = this.modelFor(this.routeName);
      this.copyArrayElements('dispoItems_' , 'includedItems');
    },
    addAllToIncluded(){
      //debugger
      this.copyArrayElements('dispoItems' , 'includedItems');
    },
    removeFromIncluded(){

    },
    RemoveAllFromIncluded(){

    }
  }
});
