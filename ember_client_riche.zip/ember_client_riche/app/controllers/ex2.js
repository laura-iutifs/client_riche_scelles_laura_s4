import Controller from '@ember/controller';


export default Controller.extend({
    actions: {
        toggleActive(service){
            //service.active!= service.active;
            Ember.set(service,'active',!Ember.get(service,'active'));
        }
    },
});
