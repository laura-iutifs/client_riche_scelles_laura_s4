import Route from '@ember/routing/route';

export default Route.extend({
  model(){
    let contact = this.get('store').createRecord({
      nom:'SCELLES',
      prenom:'Laura',
      email: 'laurascelles18@gmail.com'
    });
    return contact;
  }
});
