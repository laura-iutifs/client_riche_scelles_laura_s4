export { default } from 'ember-local-storage/serializers/serializer';
